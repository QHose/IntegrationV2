﻿Before you can begin the tutorial, preparations must be done depending on installation. 

With a Qlik Sense Desktop installation verify that you have Qlik Sense Desktop installed.Then open the PDF and begin the tutorial!

With a Qlik Sense installation you must ask your system administrator to give you access to the hub, using the QMC. Then open the PDF and begin the tutorial!

With Qlik Sense Cloud you must enter your user name and password, or register, to log in. Then open the PDF and begin the tutorial!